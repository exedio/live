/*
 * Copyright (C) 2004-2009  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

import gnu.trove.TIntHashSet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.exedio.cope.util.Pool;
import com.exedio.cope.util.PoolCounter;
import com.exedio.dsmf.SQLRuntimeException;

final class Connect
{
	final long date = System.currentTimeMillis();
	final ConnectProperties properties;
	final Dialect dialect;
	final Pool<Connection> connectionPool;
	final Database database;
	final ItemCache itemCache;
	final QueryCache queryCache;
	final ClusterSender clusterSender;
	final ClusterListener clusterListener;
	final boolean logTransactions;
	
	Connect(
			final Types types,
			final Revisions revisions,
			final ConnectProperties properties)
	{
		this.properties = properties;
		
		final DialectParameters dialectParameters;
		Connection probeConnection = null;
		try
		{
			probeConnection = DriverManager.getConnection(
					properties.getDatabaseUrl(),
					properties.getDatabaseUser(),
					properties.getDatabasePassword());
			dialectParameters = new DialectParameters(properties, probeConnection);
		}
		catch(SQLException e)
		{
			throw new SQLRuntimeException(e, "create");
		}
		finally
		{
			if(probeConnection!=null)
			{
				try
				{
					probeConnection.close();
					probeConnection = null;
				}
				catch(SQLException e)
				{
					throw new SQLRuntimeException(e, "close");
				}
			}
		}
		
		this.dialect = properties.createDialect(dialectParameters);
		this.connectionPool = new Pool<Connection>(
				new ConnectionFactory(properties, dialect),
				properties.getConnectionPoolIdleLimit(),
				properties.getConnectionPoolIdleInitial(),
				new PoolCounter());
		this.database = new Database(
				dialect.dsmfDialect,
				dialectParameters,
				dialect,
				connectionPool,
				revisions);
		
		this.itemCache = new ItemCache(types.concreteTypeList, properties.getItemCacheLimit());
		this.queryCache = new QueryCache(properties.getQueryCacheLimit());
		
		if(database.cluster)
		{
			final ClusterConfig config = ClusterConfig.get(properties);
			if(config!=null)
			{
				this.clusterSender   = new ClusterSender  (config, properties);
				this.clusterListener = new ClusterListener(config, properties, clusterSender, types.concreteTypeCount, itemCache, queryCache);
			}
			else
			{
				this.clusterSender   = null;
				this.clusterListener = null;
			}
		}
		else
		{
			this.clusterSender   = null;
			this.clusterListener = null;
		}
		
		this.logTransactions = properties.getTransactionLog();
	}
	
	void close()
	{
		if(clusterSender!=null)
			clusterSender.close();
		if(clusterListener!=null)
			clusterListener.close();
		
		database.close();
	}
	
	void invalidate(final TIntHashSet[] invalidations)
	{
		itemCache.invalidate(invalidations);
		queryCache.invalidate(invalidations);
		if(clusterSender!=null)
			clusterSender.invalidate(invalidations);
	}
}
