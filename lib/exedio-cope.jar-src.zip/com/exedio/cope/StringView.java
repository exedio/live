/*
 * Copyright (C) 2004-2011  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

public abstract class StringView extends View<String>
	implements StringFunction
{
	private static final long serialVersionUID = 1l;

	public StringView(final Function<?>[] sources, final String name)
	{
		super(sources, name, String.class);
	}

	public SelectType<String> getValueType()
	{
		return SimpleSelectType.STRING;
	}


	// convenience methods for conditions and views ---------------------------------

	public final LikeCondition like(final String value)
	{
		return new LikeCondition(this, value);
	}

	public final LikeCondition startsWith(final String value)
	{
		return LikeCondition.startsWith(this, value);
	}

	public final LikeCondition endsWith(final String value)
	{
		return LikeCondition.endsWith(this, value);
	}

	public final LikeCondition contains(final String value)
	{
		return LikeCondition.contains(this, value);
	}

	public final LengthView length()
	{
		return new LengthView(this);
	}

	public final UppercaseView toUpperCase()
	{
		return new UppercaseView(this);
	}

	public final Condition equalIgnoreCase(final String value)
	{
		return UppercaseView.equalIgnoreCase(this, value);
	}

	public final LikeCondition likeIgnoreCase(final String value)
	{
		return UppercaseView.likeIgnoreCase(this, value);
	}

	public final LikeCondition startsWithIgnoreCase(final String value)
	{
		return UppercaseView.startsWithIgnoreCase(this, value);
	}

	public final LikeCondition endsWithIgnoreCase(final String value)
	{
		return UppercaseView.endsWithIgnoreCase(this, value);
	}

	public final LikeCondition containsIgnoreCase(final String value)
	{
		return UppercaseView.containsIgnoreCase(this, value);
	}

	@Override
	public final BindStringFunction bind(final Join join)
	{
		return new BindStringFunction(this, join);
	}
}
